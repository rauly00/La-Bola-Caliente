```markdown
# Design System Document: The Sovereign Experience

## 1. Overview & Creative North Star: "The Digital Concierge"
This design system moves away from the chaotic, high-intensity aesthetics of traditional gambling apps. Instead, we embrace **The Digital Concierge**—a North Star that prioritizes editorial sophistication, quiet confidence, and a premium "white-glove" service feel. 

The system rejects the "standard" boxy grid. We use intentional asymmetry, generous white space (breathing room), and a "layered paper" philosophy. By overlapping elements and using a high-contrast typography scale, we transform a simple lottery app into an exclusive digital club. We aren't just selling a ticket; we are presenting an invitation to a lifestyle of wealth and luck.

---

## 2. Colors: The Wealth Palette
Our colors are not just decorative; they are functional signals of value. We use a "Deep Emerald" for authority and a "Liquid Gold" for aspiration.

### The Palette
*   **Primary (Emerald):** `#00342d` — Used for high-level brand moments and core CTAs.
*   **Secondary (Gold):** `#735c00` — Our accent of wealth, reserved for "Win" states and VIP indicators.
*   **Surface Hierarchy:** 
    *   `surface`: `#f8f9fa` (The canvas)
    *   `surface-container-low`: `#f3f4f5` (Subtle sectioning)
    *   `surface-container-highest`: `#e1e3e4` (Deepest depth)

### The "No-Line" Rule
**Explicit Instruction:** Do not use 1px solid borders to separate sections. We prohibit the use of structural lines. Boundaries must be defined solely through background color shifts. For example, a `surface-container-low` section should sit directly on a `surface` background to create a "silent" edge.

### Surface Hierarchy & Nesting
Treat the UI as a physical stack. Place `surface-container-lowest` (#ffffff) cards on top of `surface-container-low` sections to create a natural, soft lift. This "paper-on-stone" effect feels more premium than a flat grid.

### The "Glass & Gradient" Rule
For floating elements (like a "Live Jackpot" ticker), use **Glassmorphism**. Apply a semi-transparent `surface` color with a 20px backdrop-blur. 
*   **Signature Textures:** Use a subtle linear gradient from `primary` (#00342d) to `primary_container` (#004d43) on main CTAs to give them a three-dimensional "jewel" depth.

---

## 3. Typography: Editorial Authority
We pair **Epilogue** (Display/Headlines) for its bold, architectural presence with **Manrope** (Body/Labels) for its modern, clean legibility.

*   **Display-LG (Epilogue, 3.5rem):** Reserved for jackpot numbers only. It should feel massive and monumental.
*   **Headline-SM (Epilogue, 1.5rem):** Use for section titles (e.g., "Your Daily Draws").
*   **Body-LG (Manrope, 1rem):** The standard for all user input and primary descriptions.
*   **Label-MD (Manrope, 0.75rem):** Use for "Time Remaining" or "Draw Date" metadata.

**Visual Identity:** Use heavy weights (Bold/ExtraBold) for headlines to convey "Trustworthiness" through stability.

---

## 4. Elevation & Depth: Tonal Layering
We do not use "drop shadows" in the traditional sense. We use ambient light.

*   **The Layering Principle:** Depth is achieved by stacking. A `surface-container-lowest` card on a `surface-container-low` background creates a 2mm "lift."
*   **Ambient Shadows:** If a card must float (like a winning notification), use a shadow with a 40px blur and 6% opacity, tinted with the `on-surface` color. It should look like a soft glow, not a dark smudge.
*   **The "Ghost Border" Fallback:** If a container needs more definition on a white background, use the `outline-variant` (#bfc9c4) at **15% opacity**. This is a "Ghost Border"—felt, but not seen.

---

## 5. Components: Custom Signature Elements

### Lottery Result Cards
*   **Structure:** No borders. Use `surface-container-lowest` (#ffffff).
*   **The "Winning Reveal":** The winning numbers should use `secondary_container` (#fed65b) circular backgrounds. 
*   **Asymmetry:** Place the Jackpot amount (Display-MD) in the top-left, and the "Draw Date" (Label-MD) vertically aligned to the right edge to break the standard horizontal flow.

### Subscription Tiers (VIP Section)
*   **Standard Tier:** Uses `surface-container-high` (#e7e8e9) with `primary` text.
*   **VIP Tier:** This is the "Hero" component. Use a gradient background (`primary` to `primary_container`). Text should be `secondary_fixed` (Gold). Use Glassmorphism on the "Select" button to let the emerald green bleed through.

### Chat Bubbles (Community/Support)
*   **User Bubble:** `primary` (#00342d) with `on_primary` text.
*   **System/Other Bubble:** `surface-container-highest` (#e1e3e4). 
*   **Style:** Large corner radius (`xl`: 1.5rem), but keep the corner pointing to the user sharp (`none`: 0px) for a custom, editorial tail.

### Buttons & Inputs
*   **Primary CTA:** `primary` (#00342d) with `xl` rounding. Add a subtle gold `secondary` inner-glow (1px) for VIP actions.
*   **Input Fields:** Use `surface_container_low`. No borders. When focused, shift the background to `surface_container_highest` and add a "Ghost Border."

---

## 6. Do’s and Don’ts

### Do:
*   **Use Verticality:** Use the Spacing Scale `12` (3rem) or `16` (4rem) between major sections to let the design breathe.
*   **Color as Information:** Use `secondary` (Gold) *only* for things that involve winning or high-value status.
*   **Textural Depth:** Use subtle grain or noise overlays on `primary` emerald backgrounds to mimic fine stationery.

### Don’t:
*   **Don't use Dividers:** Never use a horizontal line to separate list items. Use a `0.5px` background shift or simply an extra `1.5` (0.375rem) units of white space.
*   **Don't Over-Glow:** Gold should be matte or metallic, never "neon." Keep `secondary` accents sophisticated.
*   **Don't Crowd the Edge:** Maintain a minimum of `6` (1.5rem) padding on all screen edges to preserve the premium, "un-cluttered" feel.

---
**Director's Final Note:** This design system is about the *feeling* of a win before the draw even happens. Keep it clean, keep it heavy, and let the colors tell the story of wealth.```